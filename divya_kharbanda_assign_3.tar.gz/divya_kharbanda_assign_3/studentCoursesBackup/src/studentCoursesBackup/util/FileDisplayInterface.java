package studentCoursesBackup.util;

public interface FileDisplayInterface 
{
	void writeToFile(String file, TreeBuilder tree);
}
