package studentCoursesBackup.util;

import java.io.IOException;
import java.io.PrintWriter;

import studentCoursesBackup.util.MyLogger.DebugLevel;

/**
 * This class is used to print the output nodes in output
 * file and in console.
 */
public class Results implements StdoutDisplayInterface, FileDisplayInterface {

	DebugLevel res;
	String message;
	
	public void writeToStdout(TreeBuilder treeBuilder) 
	{
		message = treeBuilder.write();
		MyLogger.writeMessage(message, res);
	}
	public void writeToFile(String output,TreeBuilder treeBuilder) 
	{
		try 
		{
			PrintWriter writer = new PrintWriter(output);
			writer.println(treeBuilder.write());
			writer.close();
		} 
		catch (IOException e) 
		{
			message = "Output File not found";
			MyLogger.writeMessage(output, res);
		} 
	}
}
