package studentCoursesBackup.util;

import studentCoursesBackup.myTree.Node;
import studentCoursesBackup.util.MyLogger.DebugLevel;

/**
 *  Reference : https://www.geeksforgeeks.org/binary-search-tree-set-2-delete/
 *
 */
public class TreeBuilder 
{
	DebugLevel treeBuilder;
	Node root;
	String returnString = "";
	Node nodeClone1, nodeClone2;
	String message="";
	
	public void search(int key) 
	{
		root = searchCourse(root, key);
	}
	public Node searchCourse(Node root, int key) 
	{
		if (root == null || root.node == key) 			
		{
			return root;
		}
		if (root.node > key)
		{
			return searchCourse(root.left, key);			
		}
		else		
		{
			return searchCourse(root.right, key);			
		}
	}
	 /**
	  * 	 Inserting the contents to tree recursively by checking the right and left nodes
	  */
	public Node insertCourse(Node root, int key, String newCource) {

		if (root == null) 
		{
			root = new Node(key, newCource);
			return root;
		}
		if (key < root.node)
		{
			root.left = insertCourse(root.left, key, newCource);
		}
		else if (key > root.node)
		{
			root.right = insertCourse(root.right, key, newCource);
		}
		else if (key == root.node) 
		{
			if (!root.course.contains(newCource)) 
			{
				root.course.add(newCource);
			}
		}
		return root;
	}
	 /**
	  * Inserting the contents to tree recursively by checking the right and left nodes	
	  */
	
	public Node insertCourseRecursive(Node root, Node type1) 
	{
		if (root == null) 
		{
			root = type1;
			return root;
		}
		if (type1.node < root.node)
		{
			root.left = insertCourseRecursive(root.left, type1);
		}
		else if (type1.node > root.node)
		{
			root.right = insertCourseRecursive(root.right, type1);
		}
		else if (type1.node == root.node) 
		{
			root = type1;
		}
		return root;
	}
	 /**
	  * 	recursive delete the course if it exits
	  * 	and updating the same  
	  */
	public Node deleteCourse(Node root, String deleteCource, int key) {
		if (root == null) 
		{
			return root;
		}
		if ((key == root.node) && (root.course.contains(deleteCource))) 
		{
				root.course.remove(deleteCource);
		}
		else if (key < root.node) 
		{
			root.left = deleteCourse(root.left, deleteCource, key);
		} 
		else if (key > root.node) 
		{
			root.right = deleteCourse(root.right, deleteCource, key);
		}  
		return root;
	}
	
	 /**
	  * 	inserting the node as it comes from the input file  
	  */
	public Node[] insert(String fullCourse) 
	{
		String[] course = fullCourse.split(":");
		int key = Integer.parseInt(course[0]);
		String newCource = course[1];
		
		if((Integer.parseInt(course[0])<0000) || (Integer.parseInt(course[0])>9999))
		{
			message = key+" Course Number to be Added is Invalid. Course Number should be a 4 digit integer value";
			MyLogger.writeMessage(message, treeBuilder);
			System.exit(0);
			return null;
		}
		
		if((course[1].length() > 1) || (course[1].length() < 1))
		{
			message = newCource+" -Course Name to be Added is Invalid. It should be single Digit Value";
			MyLogger.writeMessage(message, treeBuilder);
			System.exit(0);
			return null;
		}
		else if ((course[1].length() == 1) && ((Integer.parseInt(course[0])>=0000) && (Integer.parseInt(course[0])<=9999)))
		{
			if((newCource.contains("A")) || (newCource.contains("B")) || (newCource.contains("C")) ||
					(newCource.contains("D")) || (newCource.contains("E")) || (newCource.contains("F"))
					|| (newCource.contains("G")) || (newCource.contains("H")) || (newCource.contains("I"))
					|| (newCource.contains("J")) || (newCource.contains("K")))
			{
				root = insertCourse(root, key, newCource);
				Node[] newNode = new Node[2];
				newNode[0] = root.clone();
				newNode[1] = root.clone();
				root.observerA = newNode[0];
				root.observerB = newNode[1];
				return newNode;
			} 
			else
			{
				message = newCource+" -Course Name to be Added is Invalid. Course Name should be between A and K";
				MyLogger.writeMessage(message, treeBuilder);
				System.exit(0);
			}
		}
		else
		{
			message = "Trying to add multiple cources for b-id "+key+". Hence, ignored.";
			MyLogger.writeMessage(message, treeBuilder);
			System.exit(0);
		}
		return null;
	}
	public void insertNewCourse(Node node) 
	{
		root = insertCourseRecursive(root, node);
		root.observerA = null;
		root.observerB= null;
	}
	public void finalNodes(Node root) 
	{
		if (root != null) 
		{
			finalNodes(root.left);
			returnString = returnString + root.node + ":" + root.course + "\n";
			finalNodes(root.right);
		}
	}
	public void delete(String line) 
	{
		String[] courseNo = line.split(":");
		int key = Integer.parseInt(courseNo[0]);
		String deleteCource = courseNo[1];
		
		if((Integer.parseInt(courseNo[0])<0000) || (Integer.parseInt(courseNo[0])>9999))
		{
			message = key+" -Course Number to be deleted is Invalid. Course Number should be a 4 digit integer value";
			MyLogger.writeMessage(message, treeBuilder);
			System.exit(0);			
		}
		if((courseNo[1].length() > 1) || (courseNo[1].length() < 1))
		{
			message = deleteCource+" -Course Name to be deleted is Invalid. It should be single Digit Value";
			MyLogger.writeMessage(message, treeBuilder);
			System.exit(0);
		}
		else if ((courseNo[1].length() == 1) && ((Integer.parseInt(courseNo[0])>=0000) && (Integer.parseInt(courseNo[0])<=9999)))
		{
			if((deleteCource.contains("A")) || (deleteCource.contains("B")) || (deleteCource.contains("C")) ||
					(deleteCource.contains("D")) || (deleteCource.contains("E")) || (deleteCource.contains("F"))
					|| (deleteCource.contains("G")) || (deleteCource.contains("H")) || (deleteCource.contains("I"))
					|| (deleteCource.contains("J")) || (deleteCource.contains("K")))
			{
				root = deleteCourse(root, deleteCource, key);
				root.notifyAll(root);
			}
			else
			{
				message = deleteCource +" -Course Name to be deleted is Invalid. Course Name should be between A and K";
				MyLogger.writeMessage(message, treeBuilder);
				System.exit(0);
			}
		}
	}
	public String write() {
		// TODO Auto-generated method stub
		returnString = "";
		finalNodes(root);
		return returnString;
	}
}
