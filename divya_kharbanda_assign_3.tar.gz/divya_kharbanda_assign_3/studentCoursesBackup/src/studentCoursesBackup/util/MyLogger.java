package studentCoursesBackup.util;

/**
 * This class is for the debugging purpose and print statements
 *
 */
public class MyLogger 
{
	
	public static enum DebugLevel 
	{ 
		driver, FILE_PROCESSOR, treeBuilder, res
    };
    static DebugLevel debugLevel;    
	public  void setDebugValue (int levelIn) 
    {
		switch (levelIn) 
    	{
    		case 4: debugLevel = DebugLevel.res; break;
			case 3: debugLevel = DebugLevel.treeBuilder; break;
	    	case 2: debugLevel = DebugLevel.driver; break;
	    	case 1: debugLevel = DebugLevel.FILE_PROCESSOR; break;
	    }
     }
    public static void setDebugValue (DebugLevel levelIn) {
    	debugLevel = levelIn;
        }

        public static void writeMessage (String     message  ,
                                         DebugLevel levelIn ) {
    	if (levelIn == debugLevel)
    	    System.out.println(message);
        }

        public String toString() 
        {
        	return "The debug level has been set to the following " + debugLevel;
        }
}
