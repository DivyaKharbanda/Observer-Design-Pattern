package studentCoursesBackup.myTree;

public interface SubjectI 
{	
	void notifyAll(Node i);
}
