package studentCoursesBackup.myTree;

import java.util.ArrayList;

public class Node implements Cloneable, SubjectI, ObserverI
{
	public ArrayList<String> course = new ArrayList<String>();
	public int node;
	public Node left;
	public Node right;
	public Node observerA;
	public Node observerB;
	
	public Node(int bNumber, String courseName) 
	{
		node = bNumber;
		course.add(courseName);
		left = null;
		right = null;
	}

	public  Node clone() 
	{
		Node newNode = null;
		try 
		{
			newNode = (Node) super.clone();
		} 
		catch (CloneNotSupportedException e) 
		{
			e.printStackTrace();
		}
		return newNode;
	}
	
	@Override
	public void update(Node update, Node typ) {
	}
	
	@Override
	public void notifyAll(Node i) 
	{
		
	}
}
