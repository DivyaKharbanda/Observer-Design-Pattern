package studentCoursesBackup.myTree;

public interface ObserverI 
{	
	void update(Node update,Node type);
}