package studentCoursesBackup.driver;

import java.io.FileNotFoundException;


import studentCoursesBackup.myTree.Node;
import studentCoursesBackup.util.FileProcessor;
import studentCoursesBackup.util.MyLogger;
import studentCoursesBackup.util.MyLogger.DebugLevel;
import studentCoursesBackup.util.Results;
import studentCoursesBackup.util.TreeBuilder;

public class Driver {

	static DebugLevel driver;
	public static void main(String[] args) 
	{
		FileProcessor fileProcessorInstance1 = new FileProcessor();
		FileProcessor fileProcessorInstance2 = new FileProcessor();
		Results res = new Results();
		TreeBuilder treeInstance1 = new TreeBuilder();
		TreeBuilder treeInstance2 = new TreeBuilder();
		TreeBuilder treeInstance3 = new TreeBuilder();
		
		String message;
		
		String line;
		if(args.length == 6)
		{
			String input = args[0];
			String delete = args[1];
			String output1 = args[2];
			String output2 = args[3];
			String output3 = args[4];
			int debugLevel = Integer.parseInt(args[5]);
			//MyLogger lg = new MyLogger();
			//lg.setDebugValue(debugLevel);
			if((args[0].equals("input.txt")) && (args[1].equals("delete.txt")) && (args[2].equals("output1.txt"))
					&& (args[3].equals("output2.txt")) && (args[4].equals("output3.txt")) && ((debugLevel>=1) && (debugLevel<=4))) 
			{
			try {
				while ((line = fileProcessorInstance1.ReadLine(input)) != null) 
				{
					Node[] nodeInstance = new Node[2];
					try 
					{
						nodeInstance = treeInstance1.insert(line);
						if (nodeInstance[0] != null) 
						{
							treeInstance2.insertNewCourse(nodeInstance[0]);
							treeInstance3.insertNewCourse(nodeInstance[1]);
						}
					}
					catch(ArrayIndexOutOfBoundsException e) 
					{
					//	System.out.println("Please check the courses");
						message = "Please check the courses";
						MyLogger.writeMessage(message, driver);
					}
				}
			}
			catch (FileNotFoundException e) 
			{
				//System.out.println("Input File not Found");
				message = "Input File not Found";
				MyLogger.writeMessage(message, driver);
				System.exit(0);
			}
			//System.out.println("Main Tree: ");
			message = "Main Tree: ";
			MyLogger.writeMessage(message, driver);
			res.writeToStdout(treeInstance1);
			
			message = "*******************************************************";
			MyLogger.writeMessage(message, driver);
			try {
				while ((line = fileProcessorInstance2.ReadLine(delete)) != null) 
				{
					treeInstance1.delete(line);
				}
			} catch (FileNotFoundException e) 
			{
				//System.out.println("delete.txt File not Found");
				message = "delete.txt File not Found";
				MyLogger.writeMessage(message, driver);
				System.exit(0);
			}
			catch (NullPointerException e) 
			{
				//System.out.println("File is empty");
				message = "File is empty";
				MyLogger.writeMessage(message, driver);
			}
			//System.out.println("Tree1 is as follows: ");
			message = "Tree1 is as follows: ";
			MyLogger.writeMessage(message, driver);
			res.writeToStdout(treeInstance1);
		    
			//System.out.println("*******************************************************");
			message = "*******************************************************";
			MyLogger.writeMessage(message, driver);
			
			//System.out.println("Tree2 is as follows: ");
			message = "Tree2 is as follows: ";
			MyLogger.writeMessage(message, driver);
			res.writeToStdout(treeInstance2);
			
			//System.out.println("*******************************************************");
			message = "*******************************************************";
			MyLogger.writeMessage(message, driver);
			
			//System.out.println("Tree3 is as follows: ");
			message = "Tree3 is as follows: ";
			MyLogger.writeMessage(message, driver);
			res.writeToStdout(treeInstance3);
			
			//System.out.println("*******************************************************");
			message = "*******************************************************";
			MyLogger.writeMessage(message, driver);
			res.writeToFile(output1, treeInstance1);
			res.writeToFile(output2, treeInstance2);
			res.writeToFile(output3, treeInstance3);
			}
			else if ((!(args[0].equals("input.txt"))) || (!(args[1].equals("delete.txt"))) || (!(args[1].equals("output1.txt")))
					|| (!(args[1].equals("output2.txt"))) || (!(args[1].equals("output3.txt")) || (debugLevel<1) || (debugLevel>4))) 
			{
				//System.out.println("Files names should be 'input.txt','delete.txt','output1.txt', 'output2.txt', and 'output3.txt'");
				message = "Files names should be 'input.txt','delete.txt','output1.txt', 'output2.txt', and 'output3.txt'"
						+ " and the Debug level should be between 1 and 4 (inclusive)";
				MyLogger.writeMessage(message, driver);
				System.exit(0);
			}
		}
		else if (!(args.length == 6))
		{
			//System.out.println("Invalid number of arguements Entered. It should be 5");
			message = "Invalid number of arguements Entered. It should be 6   : "+args.length;
			
			for (int i=0; i<args.length;i++)
			{
				System.out.println(args[i]);
			}
			MyLogger.writeMessage(message, driver);
			System.exit(0);
		} 	
	}}
